from django.urls import path
from .views import *

urlpatterns = [
    
    path('create-delivery-boy/', CreateDeliveryBoyView.as_view(), name='create-delivery-boy'),
    path('delivery-boys/', DeliveryBoyListView.as_view(), name='delivery-boy-list'),
    path('delivery-boys/<int:id>/', DeliveryBoyDetailView.as_view(), name='delivery-boy-detail'),
    path('delivery-boy/login/', DeliveryBoyLoginView.as_view(), name='delivery-boy-login'),
    path('delivery-boy/verify-otp/', DeliveryBoyOTPVerifyView.as_view(), name='delivery-boy-verify-otp'),
    path('delivery-boy/<int:delivery_boy_id>/update-status/', DeliveryBoyStatusUpdateView.as_view(), name='update-delivery-boy-status'),
    path('delivery-boys/active/', ActiveDeliveryBoysView.as_view(), name='active-delivery-boys'),
    path('delivery-boys/inactive/', InactiveDeliveryBoysView.as_view(), name='inactive-delivery-boys'),


]
