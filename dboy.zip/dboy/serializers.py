from rest_framework import serializers
from .models import *

class DeliveryBoySerializer(serializers.ModelSerializer):
    class Meta:
        model = DeliveryBoy
        fields = ['email', 'mobile_number', 'name', 'vehicle_type', 'vehicle_number', 'gender', 'dob', 'identity_proof', 'is_active']
        extra_kwargs = {
            'email': {'required': True},
            'mobile_number': {'required': True},
            'name': {'required': True},
            'vehicle_type': {'required': True},
            'vehicle_number': {'required': True},
            'gender': {'required': True},
            'dob': {'required': True},
            'identity_proof': {'required': True},
        }

    def create(self, validated_data):
        delivery_boy = DeliveryBoy.objects.create_user(**validated_data)
        return delivery_boy
    
class DeliveryBoySerializer(serializers.ModelSerializer):
    class Meta:
        model = DeliveryBoy
        fields = ['id', 'email', 'mobile_number', 'name', 'vehicle_type', 'vehicle_number', 'gender', 'dob', 'identity_proof','is_working']

class DeliveryBoyLoginSerializer(serializers.Serializer):
    email = serializers.EmailField()

class DeliveryBoyOTPVerifySerializer(serializers.Serializer):
    email = serializers.EmailField()
    otp = serializers.CharField(max_length=6)

class DeliveryBoyStatusUpdateSerializer(serializers.Serializer):
    is_working = serializers.BooleanField()

    def update(self, instance, validated_data):
        instance.is_working = validated_data.get('is_working', instance.is_working)
        instance.save()
        return instance